# socket-chat

Aplicação socket

Necessário ter instalado o Node.js.

Para rodar execute os comandos:
    1 - npm install 
    2 - npm start
    3 - abrir varias abas no browser
    4 - enviar mensagem em uma aba e receber em todas as outras.